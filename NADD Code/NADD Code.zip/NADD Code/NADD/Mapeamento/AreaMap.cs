﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using NADD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NADD.Mapeamento
{
    public class AreaMap : IEntityTypeConfiguration<Area>
    {

            public void Configure(EntityTypeBuilder<Area> builder)
            {
                builder.HasKey(d => d.AreaId);
                builder.Property(d => d.NomeArea).IsRequired();

                builder.HasOne(d => d.AreaId).WithMany(d => d.CursoId).HasForeignKey(d => d.AreaId);
                builder.HasOne(d => d.TipoDespesas).WithMany(d => d.Despesas).HasForeignKey(d => d.TipoDespesaId);

                builder.ToTable("Despesas");
            }
        
    }
}
